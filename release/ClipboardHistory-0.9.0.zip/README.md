# Lertaro 剪贴板历史插件

Lertaro 原生剪贴板历史插件：全局热键唤起独立面板，支持文本 / 图片 / 文件三类记录、按天时间线筛选、来源应用筛选、悬停预览全文、历史持久化。

> 验证环境：Lertaro **5.6.7**（PluginSdk 1.8.6）/ Windows 11 / .NET 10（宿主自带运行时，用户无需安装 .NET）

## 功能

- **文本记录**：所有应用的文字复制，单条上限 100,000 字符；全文检索 + 模糊匹配
- **图片记录**：截图 / 聊天图复制（CF_DIB / CF_DIBV5 / PNG），以 PNG 缓存落盘，面板显示缩略图，浮窗可缩放（Ctrl+滚轮）查看长图
- **文件记录**：资源管理器复制文件 / 文件夹（CF_HDROP），记录路径清单，回车写回剪贴板直接粘贴
- **独立面板**（Win+V 风格）：打字即过滤、↑↓ 选择、Enter 粘贴并自动把焦点还给原窗口
- **悬停预览**：鼠标悬停条目弹出浮窗 —— 文本可选中复制、图片可缩放、长图可滚动
- **时间线筛选**：点击"今天"等时间分组头，按天筛选历史
- **来源筛选**：搜索 `from:weixin` 或用来源下拉，只看某个应用里复制的内容
- **四种敏感内容排除**（Clipboard Viewer Ignore 等格式，密码管理器复制的密码不进历史）
- **历史持久化**：文本全文 + 图片落盘 JSON 快照，重启宿主自动恢复
- **配置面板**：热键（即时生效）、触发词、条数上限、保留天数、暂停记录、记录图片、单张图片上限、持久化开关、悬停预览开关

## 安装

### 方式一：install.ps1（推荐）

1. 下载 Release 里的 `ClipboardHistory-x.y.z.zip` 并解压
2. 右键 `install.ps1` → 使用 PowerShell 运行（会自动请求管理员权限）
3. 重启 Lertaro，按默认热键 `Ctrl+Shift+V` 唤起面板

### 方式二：手动

1. 解压 zip
2. 把 `Lertaro.Plugins.ClipboardHistory` 文件夹整个复制到 `C:\Program Files\Lertaro\Plugins\`（需管理员权限）
3. 重启 Lertaro

日志中看到 `history restored` 即恢复成功；数据目录在 `%LOCALAPPDATA%\Lertaro\Lertaro.Plugins.ClipboardHistory\`。

## 使用

| 操作 | 方式 |
|---|---|
| 打开 / 关闭面板 | 全局热键（默认 `Ctrl+Shift+V`，可在设置中改，支持 Win 组合） |
| 搜索框调用 | 输入触发词 `cb` / `clip`（可跟过滤词，如 `cb token`） |
| 选择 | ↑↓ 方向键（跳过分组头） |
| 粘贴 | Enter（写回剪贴板并把焦点还给原窗口，直接 Ctrl+V） |
| 查看全文 | 鼠标悬停条目，浮窗内可选中复制 |
| 图片缩放 | 浮窗内 Ctrl+滚轮（1x-8x），双击还原，长图滚轮下滑 |
| 按天筛选 | 点击"今天 / 昨天 / 本周早些时候"等时间分组头 |
| 按来源筛选 | 搜索 `from:weixin`，或用搜索框右侧下拉 |
| 固定 / 删除 | `Ctrl+P` / `Ctrl+Delete` |

## 设置项

热键 · 触发词 · 条数上限（默认 5000）· 保留天数（默认 30，0 = 不限时）· 暂停记录 · 显示来源进程 · 记录图片 · 单张图片上限（默认 20MB）· 重启保留历史（默认开，**文本明文落盘**，敏感内容请配合"暂停记录"）· 悬停预览

## 已知限制

- 搜索窗（`cb` 触发词）只展示文本条目；图片 / 文件请在面板中使用
- 富文本复制只保留其中的纯文本部分（粘贴为纯文本）
- 复制的文件被移动 / 删除后，回写时自动剔除失效路径
- 插件与宿主同进程加载：宿主大版本升级后可能需要重新编译适配

## 构建

需要 [.NET 10 SDK](https://dotnet.microsoft.com/download)（本仓库以 10.0.401 构建）与 Lertaro 安装目录下的 `Lertaro.PluginSdk.dll`：

```powershell
C:\Users\<你>\.dotnet\dotnet.exe build src\Lertaro.Plugins.ClipboardHistory\Lertaro.Plugins.ClipboardHistory.csproj -c Release
```

产物在 `src\...\bin\Release\net10.0-windows\`，复制 dll 到 Lertaro 的 `Plugins\` 目录即可。

## License

MIT
